//
//  AmountViewCell.swift
//  BudgetBook
//
//  Created by 张婧莹 on 2019/5/17.
//  Copyright © 2019年 张婧莹. All rights reserved.
//

import UIKit

class AmountViewCell: UITableViewCell {
    @IBOutlet weak var amountTextField: UITextField!
}
